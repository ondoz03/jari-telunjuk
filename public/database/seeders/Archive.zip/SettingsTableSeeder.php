<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('settings')->delete();
        
        \DB::table('settings')->insert(array (
            0 => 
            array (
                'id' => 1,
                'uuid' => '4eed49c1-545e-4a22-80b9-f415c0b43465',
                'type' => 'plain',
                'key' => 'title_header',
                'value' => 'Discover books you’ll love',
                'created_at' => NULL,
                'updated_at' => '2023-08-02 17:07:59',
            ),
            1 => 
            array (
                'id' => 2,
                'uuid' => '9bbd85c6-8a12-484c-8a29-aff99eba5497',
                'type' => 'plain',
                'key' => 'body_header',
                'value' => 'Enter a book you like and the site will analyse our huge database of real readers\' favorite books to provide book recommendations and suggestions for what to read next',
                'created_at' => NULL,
                'updated_at' => '2023-08-02 16:57:06',
            ),
            2 => 
            array (
                'id' => 3,
                'uuid' => '9bbd85c6-8a12-484c-8a29-aff99eba5496',
                'type' => 'plain',
                'key' => 'qoutes_header',
                'value' => 'The person, be it gentleman or lady, who has not pleasure in a good novel, must be intolerably stupid.',
                'created_at' => NULL,
                'updated_at' => '2023-08-07 22:40:57',
            ),
            3 => 
            array (
                'id' => 4,
                'uuid' => '9bbd85c6-8a12-484c-8a29-aff99eba5496',
                'type' => 'plain',
                'key' => 'by_quotes',
                'value' => 'Jane Austen, Northanger Abbey',
                'created_at' => NULL,
                'updated_at' => '2023-08-07 22:41:07',
            ),
        ));
        
        
    }
}